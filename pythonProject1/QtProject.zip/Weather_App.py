import sqlite3
import datetime as dt
import sys
import requests as req
import pyqtgraph as pg
from PyQt5.QtGui import *
from PyQt5 import uic, Qt
from PyQt5.QtWidgets import QApplication, QPushButton, QWidget, QDialog, QLineEdit
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem, QVBoxLayout, QMessageBox
from PyQt5.QtCore import QRect
import gettext
import pycountry
import csv
from ast import literal_eval

current_user = ""
current_users_history = []
f = False


class Login(QDialog):
    def __init__(self, parent=None):
        super(Login, self).__init__(parent)
        self.textName = QLineEdit(self)
        self.textPass = QLineEdit(self)
        self.buttonLogin = QPushButton('Login', self)
        self.buttonLogin.clicked.connect(self.handledata)
        self.buttonRegister = QPushButton('Register', self)
        self.buttonRegister.clicked.connect(self.redirect_reg)
        layout = QVBoxLayout(self)
        layout.addWidget(self.textName)
        layout.addWidget(self.textPass)
        layout.addWidget(self.buttonLogin)
        layout.addWidget(self.buttonRegister)

    def handledata(self):
        with open('Users.csv', mode='r', encoding='utf-8') as csvfile:
            reader = list(csv.reader(csvfile, delimiter=';', quotechar="'"))
            self.users = {}
            for el in reader:
                if el:
                    self.users[el[0]] = el[1:]
        print(self.users)
        if (self.textName.text() in self.users and
                self.textPass.text() == self.users[self.textName.text()][0]):
            global current_user
            current_user = self.textName.text()
            global current_users_history
            current_users_history = ["История запросов:"] + literal_eval(self.users[self.textName.text()][1])
            global f
            f = True
            self.accept()
        else:
            QMessageBox.warning(self, 'Error', 'Неправильное имя пользователя или пароль')

    def redirect_reg(self):
        self.window = Register()
        self.window.exec()


class Register(QDialog):
    def __init__(self, parent=None):
        super(Register, self).__init__(parent)
        self.username = QLineEdit(self)
        self.userpassword = QLineEdit(self)
        self.userpassword_checker = QLineEdit(self)
        self.buttonRegister = QPushButton('Submit', self)
        self.buttonRegister.clicked.connect(self.handledata)
        layout = QVBoxLayout(self)
        layout.addWidget(self.username)
        layout.addWidget(self.userpassword)
        layout.addWidget(self.userpassword_checker)
        layout.addWidget(self.buttonRegister)

    def handledata(self):
        if self.userpassword.text() == self.userpassword_checker.text():
            with open('Users.csv', mode='a', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile, delimiter=';', quoting=csv.QUOTE_MINIMAL)
                writer.writerow([self.username.text(), self.userpassword.text(), []])
            self.accept()
        else:
            QMessageBox.warning(self, 'Error', 'Пароли не совпадают')


russian = gettext.translation("iso3166", pycountry.LOCALES_DIR, languages=["ru"])
russian.install()


def get_country(code):
    rus = pycountry.countries.get(alpha_2=code)
    return _(rus.name)


def wind_direction(degrees):
    value = int((degrees / 22.5) + .5)
    directions = ["С", "ССВ", "СВ", "ВСВ", "В", "ВЮВ", "ЮВ", "ЮЮВ", "Ю", "ЮЮЗ", "ЮЗ", "ЗЮЗ", "З", "ЗСЗ", "СЗ", "ССЗ"]
    return directions[(value % 16)]


appid = "9d0864cfefebb1ec3592e7379f7776af"
custom_font = QFont('Monttserat', 14)


class CityInputForm(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("WA_inputcity.ui", self)
        pixmap = QPixmap('usericon.png')
        self.user_img.setPixmap(pixmap)
        self.user.setText(current_user)
        self.history.setDuplicatesEnabled(False)
        self.history.addItems(current_users_history)
        self.history.setAutoFillBackground(True)
        self.history.view().pressed.connect(self.handleComboBoxPressed)
        self.history.setStyleSheet("color : rgb(97, 182, 255);"
                                   "background-color : white")
        self.user_img.resize(pixmap.width(), pixmap.height())
        self.btn.clicked.connect(self.run)
        self.authorize.clicked.connect(self.authorization)
        self.btn.setFont(custom_font)
        self.btn.setStyleSheet("background-color : rgb(97, 182, 255);"
                               "selection-color: white;"
                               )
        self.cityname.setFont(custom_font)
        self.cityname.setPlaceholderText("Введите название населённого пункта")

    def locate_user(self):
        self.user.setText(current_user)
        self.history.addItems(current_users_history)

    def handleComboBoxPressed(self):
        print(self.history.currentText(), self.history.currentIndex())
        if self.history.currentText() != "История запросов:":
            self.cityname.setText(str(self.history.currentText()))

    def authorization(self):
        self.login_form = Login()
        self.login_form.exec()
        if self.login_form.finished and f:
            self.locate_user()

    def run(self):
        self.city = self.cityname.text()
        self.city = self.city.capitalize()
        with open('Users.csv', mode='r', encoding='utf-8') as csvfile:
            reader = list(csv.reader(csvfile, delimiter=';', quotechar="'"))
            self.users = {}
            ct = 0
            lst_back = []
            for el in reader:
                if el:
                    if el[0] == current_user:
                        idrow = ct
                    self.users[el[0]] = el[1:]
                    lst_back.append(el)
                    ct += 1
        if current_user:
            new = self.users[current_user]
            x = literal_eval(new[1])
            x.append(self.city)
            new[1] = x
            with open('Users.csv', mode='w', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile, delimiter=';', quoting=csv.QUOTE_MINIMAL)
                for i in range(ct):
                    if i == idrow:
                        writer.writerow([current_user] + new)
                    else:
                        writer.writerow(lst_back[i])
        try:
            response = req.get("http://api.openweathermap.org/data/2.5/weather",
                               params={'q': self.city, 'lang': 'ru', 'units': 'metric',
                                       'APPID': appid})
            self.weather = response.json()
            print(self.weather)
            if self.weather["cod"] != 200:
                self.cityname.setText("Неверно введено название")
            else:
                self.window = TodayForm(self.city, self.weather)
                self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
                self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                          "selection-color: white;"
                                          "selection-background-color: white;"
                                          "color: rgb(255,255,255);")
                QApplication.setFont(custom_font, "QLabel")
                QApplication.setFont(custom_font, "QPushButton")
                self.window.setGeometry(100, 100, 1500, 800)
                self.window.show()
                self.close()
        except Exception as e:
            print(e)


class TodayForm(QWidget):
    def __init__(self, city, weather):
        super().__init__()
        uic.loadUi("WA_showtoday.ui", self)
        pixmap = QPixmap('usericon.png')
        self.user.setText(current_user)
        self.user_img.setPixmap(pixmap)
        self.user_img.resize(pixmap.width(), pixmap.height())
        self.horizontalLayout.setGeometry(QRect(0, 0, 1400, 700))
        self.back.clicked.connect(self.go_back)
        self.back.setStyleSheet("background-color : rgb(97, 182, 255);"
                                "selection-color: white;"
                                )
        self.forward.clicked.connect(self.go_forward)
        self.forward.setStyleSheet("background-color : rgb(97, 182, 255);"
                                   "selection-color: white;"
                                   )

        self.city = city
        self.weather = weather
        try:
            img_param = self.weather["weather"][0]["main"]
            cntr = get_country(self.weather["sys"]["country"])
            self.cityinfo.setText(f'''Погода в городе {self.city}, {cntr},
{str(dt.datetime.utcfromtimestamp(weather["dt"]).strftime('%Y-%m-%d %H:%M'))}:''')
            try:
                if img_param == "Clouds":
                    pixmap = QPixmap('clouds.jpg')
                elif img_param == "Clear":
                    pixmap = QPixmap('clear.jpg')
                elif img_param == "Rain" or img_param == "Drizzle":
                    pixmap = QPixmap('rain.jpg')
                elif img_param == "Thunderstorm":
                    pixmap = QPixmap('thunderstorm.jpg')
                elif img_param == "Snow":
                    pixmap = QPixmap('snow.jpg')
                elif img_param == "Snow":
                    pixmap = QPixmap('snow.jpg')
                elif img_param == "Atmosphere":
                    pixmap = QPixmap('atm.jpg')
                else:
                    pixmap = QPixmap('clear_tmp.jpg')
                self.image.setPixmap(pixmap)
                self.image.resize(pixmap.width(), pixmap.height())
            except Exception as ex:
                print(ex)
            try:
                self.temperature.show()
                self.temperature.setFont(QFont('Monttserat', 17))
                self.temperature.setText(f'''{str(round(self.weather["main"]["temp"], 1))}°C,
{self.weather["weather"][0]["description"]}, по ощущениям: {str(round(self.weather["main"]["feels_like"]))}°C''')
            except KeyError:
                self.temperature.setText("--°C")

            try:
                self.humidity.show()
                self.humidity.setText(f'Влажность: {str(self.weather["main"]["humidity"])}%')
            except KeyError:
                self.humidity.setText("Влажность: --%")
            try:
                self.visibility.show()
                self.visibility.setText(f'Видимость: {str(self.weather["visibility"])}м')
            except KeyError:
                self.visibility.setText("Видимость: --км")
            try:
                self.pressure.show()
                self.pressure.setText(f'Давление: {str(round(self.weather["main"]["pressure"] * 0.75))}мм.рт.ст')
            except KeyError:
                self.pressure.text_pressure.setText("давление -- ")

            try:
                self.wind.show()
                self.wind.setText(
                    f'Ветер: {str(wind_direction(int(self.weather["wind"]["deg"])))} {str(self.weather["wind"]["speed"])}м/с')
            except KeyError:
                self.wind.setText("Ветер -- м/с")
        except BaseException:
            pass

    def go_back(self):
        self.window = CityInputForm()
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "selection-color: white;"
                                  "selection-background-color: white;"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()

    def go_forward(self):
        self.window = Forecast8daysForm(self.city, self.weather)
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "selection-color: white;"
                                  "selection-background-color: white;"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()


class Forecast8daysForm(QWidget):
    def __init__(self, city, weather):
        super().__init__()
        uic.loadUi("WA_show8days.ui", self)
        pixmap = QPixmap('usericon.png')
        self.user.setText(current_user)
        self.user_img.setPixmap(pixmap)
        self.user_img.resize(pixmap.width(), pixmap.height())
        self.city = city
        self.data = []
        self.weather = weather
        self.back.clicked.connect(self.go_back)
        self.back.setStyleSheet("background-color : rgb(97, 182, 255);"
                                "selection-color: white;"
                                )
        self.forward.clicked.connect(self.go_forward)
        self.forward.setStyleSheet("background-color : rgb(97, 182, 255);"
                                   "selection-color: white;"
                                   )
        self.home.clicked.connect(self.go_home)
        self.home.setStyleSheet("background-color : rgb(97, 182, 255);"
                                "selection-color: white;"
                                )
        self.tableWidget.setStyleSheet("background-color : rgb(97, 182, 255);"
                                       "selection-color: white;"
                                       )
        q = []
        try:
            res = req.get("http://api.openweathermap.org/data/2.5/forecast",
                          params={'q': self.city, 'units': 'metric', 'lang': 'ru', 'APPID': appid})
            data = res.json()
            self.data_wa8days = []
            for el in data['list']:
                date = el['dt_txt'].split()
                x = [date[0], date[1], el['main']['temp_min'], el['weather'][0]['description'],
                     el['main']['pressure'], el['main']['humidity'], el['wind']['speed']]
                self.data_wa8days.append(x)
                q.append(x)
            con = sqlite3.connect("Weather_Data_previous_week.sqlite3")
            cur = con.cursor()
            cur.execute(f"""DROP TABLE IF EXISTS weather;""")
            cur.execute(f"""CREATE TABLE weather('date', 'time', 'temperature',
'weather', 'pressure', 'humidity', 'wind_speed')""")
            for i in range(len(self.data_wa8days)):
                cur.execute(f"""INSERT INTO weather('date', 'time', 'temperature',
    'weather', 'pressure', 'humidity', 'wind_speed') VALUES{tuple(self.data_wa8days[i])}""")
            res = cur.execute("SELECT * FROM weather").fetchall()
        except Exception as e:
            print("Exception (forecast):", e)
            pass
        self.data = q
        title = ['День', 'Время', 'Температура', 'Погодные условия',
                 'Давление', 'Влажность', 'Скорость ветра']
        self.tableWidget.setColumnCount(len(title))
        self.tableWidget.setHorizontalHeaderLabels(title)
        self.tableWidget.setRowCount(0)
        for i, row in enumerate(self.data):
            self.tableWidget.setRowCount(
                self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(
                    i, j, QTableWidgetItem(str(elem)))
        for i in range(len(title)):
            item1 = self.tableWidget.horizontalHeaderItem(i)
            item1.setForeground(QColor(97, 182, 255))
        self.tableWidget.resizeColumnsToContents()

    def go_back(self):
        self.window = TodayForm(self.city, self.weather)
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "selection-color: white;"
                                  "selection-background-color: white;"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()

    def go_forward(self):
        self.window = Forecast8days_statsForm(self.city, self.weather, self.data)
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "selection-color: white;"
                                  "selection-background-color: white;"
                                  "color: rgb(255,255,255);"
                                  'font-size: 18px;')
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()

    def go_home(self):
        self.window = CityInputForm()
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "selection-color: white;"
                                  "selection-background-color: white;"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()


class Forecast8days_statsForm(QWidget):
    def __init__(self, city, weather, data):
        super().__init__()
        uic.loadUi("WA_show8days_stats.ui", self)
        self.back.clicked.connect(self.go_back)
        self.back.setStyleSheet("background-color : rgb(97, 182, 255);"
                                "selection-color: white;"
                                )
        self.home.clicked.connect(self.go_home)
        self.home.setStyleSheet("background-color : rgb(97, 182, 255);"
                                "selection-color: white;"
                                )
        try:
            self.city = city
            self.weather = weather
            self.data = data
            self.temp_max.setReadOnly(True)
            self.temp_max_date.setReadOnly(True)
            self.temp_min.setReadOnly(True)
            self.temp_min_date.setReadOnly(True)
            self.average_temp.setReadOnly(True)
            self.average_hum.setReadOnly(True)
            self.average_pres.setReadOnly(True)
            self.weather_conds.setReadOnly(True)
            self.wind_conds.setReadOnly(True)
            print(1, self.data)
            mat = -100
            avt = avh = avp = w = ct = 0
            mit = 100
            mitd = matd = wth = ''
            week = self.data[0][0] + '--' + self.data[-1][0]
            q = {}
            graph_temp = []
            graph_dates = []
            for i in range(len(self.data)):
                ct += 1
                graph_temp.append(round(self.data[i][2], 1))
                graph_dates.append(" ".join([self.data[i][0], self.data[i][1]]))
                avt += float(self.data[i][2])
                avh += float(self.data[i][5])
                avp += float(self.data[i][4])
                if float(self.data[i][2]) > mat:
                    mat = float(self.data[i][2])
                    matd = self.data[i][0]
                if float(self.data[i][2]) < mit:
                    mit = float(self.data[i][2])
                    mitd = self.data[i][0]
                if float(self.data[i][6]) > w:
                    w = float(self.data[i][6])
                if self.data[i][3] not in q:
                    q[self.data[i][3]] = 1
                else:
                    q[self.data[i][3]] += 1
            sup = 0
            for key, el in q.items():
                if el > sup:
                    wth = key
                    sup = el
            self.temp_max.setText(str(round(mat, 1)))
            self.temp_min.setText(str(round(mit, 1)))
            self.temp_max_date.setText(str(matd))
            self.temp_min_date.setText(str(mitd))
            self.average_temp.setText(str(round(avt / ct, 1)))
            self.average_hum.setText(str(round(avh / ct, 1)))
            self.average_pres.setText(str(round(avp / ct, 1)))
            self.weather_conds.setText(str(wth))
            self.wind_conds.setText(str(round(w, 1)))
            graph_dates = dict(enumerate(graph_dates))
            print(graph_temp, graph_dates)
            stringaxis = pg.AxisItem(orientation='bottom')
            stringaxis.setTicks([graph_dates.items()])
            self.GraphWidget.addLegend()
            self.GraphWidget.setAxisItems({'bottom': stringaxis})
            self.GraphWidget.plot(list(graph_dates.keys()), graph_temp, brush=QColor(0, 0, 0),
                                  name="Ожидаемая температура", symbol='o', symbolPen=QColor(255, 255, 255),
                                  symbolBrush=0.08)
            self.GraphWidget.addLine(y=round(avt / ct, 1))
            self.GraphWidget.setBackground(QColor(255, 255, 255))
            self.GraphWidget.setStyleSheet("border : 5px solid rgb(97, 182, 255);"
                                           "color: rgb(255,255,255);")
        except Exception as e:
            print(e)

    def go_back(self):
        self.window = Forecast8daysForm(self.city, self.weather)
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "selection-color: white;"
                                  "selection-background-color: white;"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()

    def go_home(self):
        self.window = CityInputForm()
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "selection-color: white;"
                                  "selection-background-color: white;"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = CityInputForm()
    ex.show()
    ex.setAttribute(Qt.Qt.WA_StyledBackground, True)
    ex.setStyleSheet("background-color: rgb(85, 122, 240);"
                     "color: rgb(255,255,255);")
    ex.setGeometry(100, 100, 1500, 800)
    sys.exit(app.exec())
